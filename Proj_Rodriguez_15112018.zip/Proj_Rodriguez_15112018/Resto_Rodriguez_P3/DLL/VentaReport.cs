﻿namespace DLL
{
    public class VentaReport
    {
        public VentaReport()
        {

        }

        public string Operador { get; set; }
        public decimal Ventas { get; set; }
        public string Fedate { get; set; }
    }
}
