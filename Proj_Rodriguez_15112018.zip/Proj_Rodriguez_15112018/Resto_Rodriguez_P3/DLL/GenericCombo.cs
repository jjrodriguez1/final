﻿namespace DLL
{
    public class GenericCombo
    {
        public GenericCombo()
        {

        }

        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
