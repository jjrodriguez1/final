﻿namespace DLL
{
    public class Mesa
    {
        public Mesa()
        {

        }

        public int Id { get; set; }
        public int NroMesa { get; set; }
        public int EstadoId { get; set; }
		public int Asignada {get; set;}
    }
}
