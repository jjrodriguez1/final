﻿namespace DLL
{
    public class ComandaReport
    {
        public ComandaReport()
        {

        }

        public string Menu { get; set; }
        public string Fedate { get; set; }
        public string Nombre { get; set; }
    }
}
