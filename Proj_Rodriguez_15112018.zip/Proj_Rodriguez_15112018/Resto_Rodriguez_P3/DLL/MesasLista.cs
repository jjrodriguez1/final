﻿namespace DLL
{
    public class MesasLista
    {
        public MesasLista()
        {

        }

        public int? IdMp { get; set; }
        public int MesaId { get; set; }
        public int? IdOperador { get; set; }
        public int NroMesa { get; set; }
        public string Usuario { get; set; }
    }
}
