﻿namespace DLL
{
    public class OperadorLista
    {
        public OperadorLista() { }

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
        public string Estado { get; set; }
        public string TipoOperador { get; set; }
        public string Documento { get; set; }
        public string Direccion { get; set; }
        public string Usuario { get; set; }

    }
}
