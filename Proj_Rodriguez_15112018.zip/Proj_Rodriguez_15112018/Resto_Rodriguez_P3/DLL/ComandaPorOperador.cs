﻿namespace DLL
{
    public class ComandaPorOperador
    {
        public ComandaPorOperador()
        {

        }

        public int Id { get; set; }
        public int IdOperador { get; set; }
        public long IdComanda { get; set; }
    }
}
