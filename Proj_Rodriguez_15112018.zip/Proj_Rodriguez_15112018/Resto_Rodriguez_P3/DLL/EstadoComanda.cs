﻿namespace DLL
{
    public class EstadoComanda
    {
        public EstadoComanda()
        {

        }

        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
