﻿namespace DLL
{
    public class MesaPorOperador
    {
        public MesaPorOperador()
        {

        }

        public int Id { get; set; }
        public int IdOperador { get; set; }
        public int IdMesa { get; set; }
    }
}
