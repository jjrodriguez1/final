﻿namespace DLL
{
    public class MesaEstado
    {
        public MesaEstado()
        {

        }

        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
