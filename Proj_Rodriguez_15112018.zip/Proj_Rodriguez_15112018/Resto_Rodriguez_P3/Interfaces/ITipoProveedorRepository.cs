﻿namespace Interfaces
{
    public interface ITipoProveedorRepository
    {
    }
}
