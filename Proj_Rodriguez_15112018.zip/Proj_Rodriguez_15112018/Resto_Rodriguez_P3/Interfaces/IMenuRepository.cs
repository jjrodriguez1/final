﻿using DLL;

namespace Interfaces
{
    public interface IMenuRepository
    {
        bool AltaMenu(Menu menu);
    }
}
