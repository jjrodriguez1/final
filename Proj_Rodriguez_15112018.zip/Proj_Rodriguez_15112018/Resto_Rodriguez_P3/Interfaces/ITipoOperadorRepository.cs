﻿using DLL;
using System.Collections.Generic;

namespace Interfaces
{
    public interface ITipoOperadorRepository
    {
        List<TipoOperador> GetAllTipoOperador();
    }
}
