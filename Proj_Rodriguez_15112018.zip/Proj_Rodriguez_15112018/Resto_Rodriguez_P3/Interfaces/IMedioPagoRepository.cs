﻿namespace Interfaces
{
    public interface IMedioPagoRepository
    {
    }
}
