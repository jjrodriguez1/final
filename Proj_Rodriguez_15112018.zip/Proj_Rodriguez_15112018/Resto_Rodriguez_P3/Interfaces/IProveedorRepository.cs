﻿namespace Interfaces
{
    public interface IProveedorRepository
    {
    }
}
